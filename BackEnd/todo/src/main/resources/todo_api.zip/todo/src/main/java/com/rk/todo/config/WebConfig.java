package com.rk.todo.config;

public class WebConfig {

}
