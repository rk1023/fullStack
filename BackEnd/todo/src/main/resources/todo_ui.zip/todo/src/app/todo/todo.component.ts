import { Component, OnInit } from '@angular/core';
import { TodoBasicDetailsDTO } from '../welcome/welcome.component';
import { TodoDataService } from '../services/data/todo-data.service';
import { Router } from '@angular/router';
import { BasicauthService } from '../services/basicauth.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  constructor(private tododataService: TodoDataService,
    private basicauthService: BasicauthService,
    private router: Router) { }
  userTodoData: Array<TodoBasicDetailsDTO>;
  ngOnInit(): void {
    this.fillTodoData();
    console.log(this.userTodoData);
  }

  deleteTodo(todoId: number) {
    console.log('TodoComponent=>dleteTodo');
    console.log(todoId);

    this.tododataService.dleteTodo(this.basicauthService.getAuthenticatedUser(), todoId).subscribe
      (
      successResponse => this.handleSuccessResponse(successResponse)
      );
    this.fillTodoData();

  }

  addTodo() {
    console.log('TodoComponent=>addTodo');
    this.router.navigate(['todo-detail', this.basicauthService.getAuthenticatedUser(), 101]);
  }

  editTodo(todoId: number) {
    console.log('TodoComponent=>editTodo');
    console.log(todoId);

  }

  fillTodoData() {
    console.log('TodoComponent=>fillTodoData');
    this.tododataService.getToDoByUserName(this.basicauthService.getAuthenticatedUser()).subscribe
      (
      successResponse => this.handleSuccessResponse(successResponse)
      );
  }

  handleSuccessResponse(successResponse) {
    console.log('TodoComponent=>handleSuccessResponse');
    this.userTodoData = successResponse;
    console.log(this.userTodoData);
  }
}
