import { Component, OnInit } from '@angular/core';
import { BasicauthService } from '../services/basicauth.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor(
    private basicAuth: BasicauthService) { }

  title = 'todo';
  message = 'Manage Your Todo Here!';
  welcomeRouteLink = '/welcome/';
  todoRouteLink = '/todo/';

  ngOnInit(): void {
  }

  logOut()
  {
    this.basicAuth.logOut();
  }

  isUseLoggedIn()
  {
    this.welcomeRouteLink = '/welcome/' + this.basicAuth.getAuthenticatedUser();
    this.todoRouteLink = '/todo/' + this.basicAuth.getAuthenticatedUser();
    return this.basicAuth.isUserLoggedIn();
  }

  getLoggedIUser()
  {
    return this.basicAuth.getAuthenticatedUser();
  }

}
