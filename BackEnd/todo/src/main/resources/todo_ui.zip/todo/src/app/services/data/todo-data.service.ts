import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { API_BASE_URL, API_TODO_URL } from '../../app.constants';

export class TodoBasicDetailsDTO {

  constructor(private id: number, private description: string, private done: boolean) { }
}


@Injectable({
  providedIn: 'root'
})
export class TodoDataService {

  constructor(private http: HttpClient) { }

  userTodoData: Array<TodoBasicDetailsDTO>;

  dleteTodo(userName, todoId: number) {
    console.log('TodoDataService=>dleteTodo');
    return this.http.delete<TodoBasicDetailsDTO[]>(`${API_TODO_URL}/${userName}/${todoId}`);


  }

  addTodo(userName, todoDto: TodoBasicDetailsDTO) {
    console.log('TodoDataService=>dleteTodo');
    this.http.put<TodoBasicDetailsDTO[]>(`${API_TODO_URL}/${userName}`, todoDto).subscribe
      (
      successResponse => this.handleSuccessResponse(successResponse)
      );

  }
  getToDoByUserName(userName) {
    return this.http.get<TodoBasicDetailsDTO[]>(`${API_TODO_URL}/${userName}`);
  }

  fillTodoData(userName) {
    console.log('TodoDataService=>fillTodoData');
    this.getToDoByUserName(userName).subscribe
      (
      successResponse => this.handleSuccessResponse(successResponse)
      );
  }

  handleSuccessResponse(successResponse) {
    console.log('TodoDataService=>handleSuccessResponse');
    this.userTodoData = successResponse;
    console.log(this.userTodoData);
  }

}
