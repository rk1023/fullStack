export const API_BASE_URL = 'http://localhost:8080';
export const BASIC_AUTH_URL = API_BASE_URL + '/basicAuth';
export const API_TODO_URL = API_BASE_URL + '/todo';
