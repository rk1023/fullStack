import { Injectable } from '@angular/core';
import { HttpClient, HttpInterceptor, HttpHeaders, HttpRequest, HttpHandler } from '@angular/common/http';
import { BasicauthService } from '../basicauth.service';

@Injectable({
  providedIn: 'root'
})
export class HttpIntercepterBasicAuthService implements HttpInterceptor {

  constructor(private basicAuth: BasicauthService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler) {


    const authString = this.basicAuth.getAuthenticatedToken();
    const authUser = this.basicAuth.getAuthenticatedUser();

    console.log('HttpIntercepterBasicAuthService=>intercept token : ' + authString);

    if (authString && authUser)
    {
      req = req.clone({
        setHeaders: { Authorization: authString }
      });
    }
    return next.handle(req);
  }


}
