import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {  BASIC_AUTH_URL, JWT_AUTH_URL } from '../app.constants';

export class BasicAuthDTO
{
  constructor(private msg: string){}
}

export class JWTAuthDTO
{
  constructor(private token: string){}
}

@Injectable({
  providedIn: 'root'
})
export class BasicauthService {

  constructor(private http: HttpClient) { }


  validateUserJwt(username, password) {

    return this.http.post<any>(`${JWT_AUTH_URL}`, {
      username,
      password
    }).pipe(
      map(
        successResponse => {
          sessionStorage.setItem('authenticatedUser', username);
          sessionStorage.setItem('authToken', `Bearer ${successResponse.token}`);
          return successResponse;
      }
      )
    );
  }

  validateUser(userName, pwd) {
    console.log('BasicauthService=>validateUser: userName:pwd ' + userName + ':' + pwd);
    const authString = 'Basic ' + window.btoa(userName + ':' + pwd);
    const header = new HttpHeaders({ Authorization: authString });

    return this.http.get<BasicAuthDTO>(`${BASIC_AUTH_URL}`, {headers: header}).pipe(
      map(
        successResponse => {
          sessionStorage.setItem('authenticatedUser', userName);
          sessionStorage.setItem('authToken', authString);
          return successResponse;
      }
      )
    );
  }

  isUserLoggedIn() {
    return !(sessionStorage.getItem('authenticatedUser') === null);
  }

  logOut() {
    sessionStorage.removeItem('authenticatedUser');
    sessionStorage.removeItem('authToken');
  }

  // tslint:disable-next-line:align
  getAuthenticatedUser ()
  {
    return sessionStorage.getItem('authenticatedUser');
  }
   // tslint:disable-next-line:align
   getAuthenticatedToken ()
   {
     if ( this.getAuthenticatedUser())
     {
      return sessionStorage.getItem('authToken');
     }

   }


}
