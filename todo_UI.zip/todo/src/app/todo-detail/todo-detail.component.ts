import { Component, OnInit } from '@angular/core';
import { TodoDataService, TodoBasicDetailsDTO } from '../services/data/todo-data.service';
import { Router } from '@angular/router';
import { BasicauthService } from '../services/basicauth.service';
@Component({
  selector: 'app-todo-detail',
  templateUrl: './todo-detail.component.html',
  styleUrls: ['./todo-detail.component.css']
})
export class TodoDetailComponent implements OnInit {

  constructor(private tododataService: TodoDataService,
              private basicauthService: BasicauthService,
              private router: Router) { }
  descr = ' ';
  todoDto: TodoBasicDetailsDTO;
  ngOnInit(): void {
  }

  addToDo()
  {
   console.log('TodoDetailComponent=>addToDo');
   this.todoDto = new TodoBasicDetailsDTO(101, this.descr, false);
   this.tododataService.addTodo(this.basicauthService.getAuthenticatedUser(), this.todoDto);
   this.router.navigate(['todo', this.basicauthService.getAuthenticatedUser()]);
  }

}
