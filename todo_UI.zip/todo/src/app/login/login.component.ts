import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TodoComponent } from '../todo/todo.component';
import { BasicauthService } from '../services/basicauth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = '';
  pwd = '';

  invalidUserMsg = 'Invalid Username or Password!';
  isInvalidUser = false;

  validUserMsg = 'Welcome : ' + this.username;

  // intance of router

  constructor(private router: Router,
    private basicauthService: BasicauthService) {

  }

  ngOnInit(): void {
  }

  validateUser() {

    if (this.basicauthService.validateUser(this.username, this.pwd)) {
      console.log('LoginComponent=>validateUser');
      this.isInvalidUser = false;
      this.router.navigate(['welcome', this.username]);

    } else {
      this.isInvalidUser = true;
    }
  }

  validateBasicAuth() {
    console.log('LoginComponent=>validateBasicAuth');
    this.basicauthService.validateUserJwt(this.username, this.pwd).subscribe(
      successResponse => {
        console.log(successResponse);
        this.isInvalidUser = false;
        this.router.navigate(['welcome', this.username]);
      },
      errorResponse => {
        console.log(errorResponse);
        this.isInvalidUser = true;
      }
    );
    this.router.navigate(['welcome', this.username]);
  }

}
