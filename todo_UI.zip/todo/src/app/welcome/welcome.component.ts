import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TodoDataService } from '../services/data/todo-data.service';
// import { TodoService } from '../services/todo.service';


export class TodoBasicDetailsDTO {

  constructor(private id: number, private description: string, private done: boolean) { }
}

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  message = 'WelcomeComponent message';
  apiMessage = '';
  logedinUser = '';

  todoRouterLink = '/todo';
  // Activated Route
  constructor(private route: ActivatedRoute, private router2: Router,
    private todaoDataService: TodoDataService) { }

  ngOnInit(): void {

    this.logedinUser = this.route.snapshot.params['userName'];
    this.message = 'Welcome ' + this.logedinUser + '!';
    this.todoRouterLink = 'todo/' + this.logedinUser;
  }

  loadTodoData() {
    console.log('WelcomeComponent=>loadTodoData ' + this.logedinUser);
    this.todaoDataService.fillTodoData(this.logedinUser);
  }


}
