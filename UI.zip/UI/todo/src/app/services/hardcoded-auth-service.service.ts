import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HardcodedAuthServiceService {

  constructor() { }

  authenticate(username, pwd): boolean {
    console.log(this.isUserLoggedIn);
    if (pwd) {
      sessionStorage.setItem('authenticatedUser', username);
      return true;
    }
    console.log(this.isUserLoggedIn);
    return false;
  }

  isUserLoggedIn() {
    return !(sessionStorage.getItem('authenticatedUser') === null);
  }

  logOut() {
    sessionStorage.removeItem('authenticatedUser');
  }

  // tslint:disable-next-line:align
  getLoggedInUser ()
  {
    return sessionStorage.getItem('authenticatedUser');
  }


}
