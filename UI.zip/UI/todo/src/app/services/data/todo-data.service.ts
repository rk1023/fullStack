import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export class TodoBasicDetailsDTO {

  constructor(private id: number, private description: string, private done: boolean) { }
}


@Injectable({
  providedIn: 'root'
})
export class TodoDataService {

  constructor(private http: HttpClient) { }

  userTodoData: Array<TodoBasicDetailsDTO>;

  dleteTodo(userName, todoId: number) {
    console.log('TodoDataService=>dleteTodo');
    return this.http.delete<TodoBasicDetailsDTO[]>(`http://localhost:8080/todo/${userName}/${todoId}`);


  }

  addTodo(userName, todoDto: TodoBasicDetailsDTO) {
    console.log('TodoDataService=>dleteTodo');
    this.http.put<TodoBasicDetailsDTO[]>(`http://localhost:8080/todo/${userName}`, todoDto).subscribe
      (
      successResponse => this.handleSuccessResponse(successResponse)
      );

  }
  getToDoByUserName(userName) {
    console.log('TodoDataService=>getToDoByUserName: userName ' + userName);
    return this.http.get<TodoBasicDetailsDTO[]>(`http://localhost:8080/todo/${userName}`);
  }

  fillTodoData(userName) {
    console.log('TodoDataService=>fillTodoData');
    this.getToDoByUserName(userName).subscribe
      (
      successResponse => this.handleSuccessResponse(successResponse)
      );
  }

  handleSuccessResponse(successResponse) {
    console.log('TodoDataService=>handleSuccessResponse');
    this.userTodoData = successResponse;
    console.log(this.userTodoData);
  }
}
