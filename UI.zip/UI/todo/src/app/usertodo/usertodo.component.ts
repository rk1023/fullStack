import { Component, OnInit } from '@angular/core';
import { TodoBasicDetailsDTO } from '../services/data/todo-data.service';

@Component({
  selector: 'app-usertodo',
  templateUrl: './usertodo.component.html',
  styleUrls: ['./usertodo.component.css']
})
export class UsertodoComponent implements OnInit {

  constructor() { }
  userTodoData: Array<TodoBasicDetailsDTO> ;
  ngOnInit(): void {
  }

}
