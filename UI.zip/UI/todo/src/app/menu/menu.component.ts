import { Component, OnInit } from '@angular/core';
import { HardcodedAuthServiceService } from '../services/hardcoded-auth-service.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor(public authService: HardcodedAuthServiceService) { }

  title = 'todo';
  message = 'Manage Your Todo Here!';
  welcomeRouteLink = '/welcome/Rk1001';
  todoRouteLink = '/todo/Rk1001';

  ngOnInit(): void {
  }

  logOut()
  {
    sessionStorage.removeItem('authenticatedUser');
  }

  isUseLoggedIn()
  {
    this.welcomeRouteLink = '/welcome/' + this.authService.getLoggedInUser();
    this.todoRouteLink = '/todo/' + this.authService.getLoggedInUser();
    return this.authService.isUserLoggedIn();
  }

  getLoggedIUser  ()
  {
    return this.authService.getLoggedInUser();
  }

}
