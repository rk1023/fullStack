import { Component, OnInit } from '@angular/core';
import { TodoBasicDetailsDTO } from '../welcome/welcome.component';
import { TodoDataService } from '../services/data/todo-data.service';
import { HardcodedAuthServiceService } from '../services/hardcoded-auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  constructor(private tododataService: TodoDataService,
    private authService: HardcodedAuthServiceService,
    private router: Router) { }
  userTodoData: Array<TodoBasicDetailsDTO>;
  ngOnInit(): void {
    this.fillTodoData();
    console.log(this.userTodoData);
  }

  deleteTodo(todoId: number) {
    console.log('TodoComponent=>dleteTodo');
    console.log(todoId);

    this.tododataService.dleteTodo(this.authService.getLoggedInUser(), todoId).subscribe
      (
      successResponse => this.handleSuccessResponse(successResponse)
      );
    this.fillTodoData();

  }

  addTodo() {
    console.log('TodoComponent=>addTodo');
    this.router.navigate(['todo-detail', 'RK1002', 101]);
  }

  editTodo(todoId: number) {
    console.log('TodoComponent=>editTodo');
    console.log(todoId);

  }

  fillTodoData() {
    console.log('TodoComponent=>fillTodoData');
    this.tododataService.getToDoByUserName(this.authService.getLoggedInUser()).subscribe
      (
      successResponse => this.handleSuccessResponse(successResponse)
      );
  }

  handleSuccessResponse(successResponse) {
    console.log('TodoComponent=>handleSuccessResponse');
    this.userTodoData = successResponse;
    console.log(this.userTodoData);
  }
}
