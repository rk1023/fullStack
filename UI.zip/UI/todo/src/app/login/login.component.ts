import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HardcodedAuthServiceService } from '../services/hardcoded-auth-service.service';
import { TodoComponent } from '../todo/todo.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = '';
  pwd = '';

  invalidUserMsg = 'Invalid Username or Password!';
  isInvalidUser = false;

  validUserMsg = 'Welcome : ' + this.username;

  // intance of router

  constructor(private router: Router, private authService: HardcodedAuthServiceService) { }

  ngOnInit(): void {
  }

  validateUser() {

    if (this.authService.authenticate(this.username, this.pwd)) {
      console.log('LoginComponent=>validateUser');
      this.isInvalidUser = false;
      this.router.navigate(['welcome', this.username]);

    } else {
      this.isInvalidUser = true;
    }
  }

}
