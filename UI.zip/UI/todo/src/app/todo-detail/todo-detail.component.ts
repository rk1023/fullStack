import { Component, OnInit } from '@angular/core';
import { TodoDataService, TodoBasicDetailsDTO } from '../services/data/todo-data.service';
import { HardcodedAuthServiceService } from '../services/hardcoded-auth-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-todo-detail',
  templateUrl: './todo-detail.component.html',
  styleUrls: ['./todo-detail.component.css']
})
export class TodoDetailComponent implements OnInit {

  constructor(private tododataService: TodoDataService,
    private authService: HardcodedAuthServiceService,
    private router: Router) { }
  descr = ' ';
  todoDto: TodoBasicDetailsDTO;
  ngOnInit(): void {
  }

  addToDo()
  {
   console.log('TodoDetailComponent=>addToDo');
   this.todoDto = new TodoBasicDetailsDTO(101, this.descr, false);
   this.tododataService.addTodo(this.authService.getLoggedInUser(), this.todoDto);
   this.router.navigate(['todo', this.authService.getLoggedInUser()]);
  }

}
